package hus.oop.lab4.themypointclass;

public class TestMain {

}
