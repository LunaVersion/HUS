package hus.oop.Lab12_Review.integration;


public interface Integrator {
    double integrate(Polynomial poly, double lower, double upper);
}
