package hus.oop.Lab12_Review.mylist;

public interface MyIterable {
    MyIterator iterator();
}
